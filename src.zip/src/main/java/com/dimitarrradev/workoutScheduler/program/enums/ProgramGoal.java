package com.dimitarrradev.workoutScheduler.program.enums;

public enum ProgramGoal {
    STRENGTH,
    VOLUME,
    CARDIO,
    GENERAL_FITNESS,
    SPEED,
    ENDURANCE
}
