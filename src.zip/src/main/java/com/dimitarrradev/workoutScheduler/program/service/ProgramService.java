package com.dimitarrradev.workoutScheduler.program.service;

import org.springframework.stereotype.Service;

@Service
public class ProgramService {
}
