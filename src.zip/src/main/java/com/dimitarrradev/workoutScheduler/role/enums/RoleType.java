package com.dimitarrradev.workoutScheduler.role.enums;

public enum RoleType {
    USER, ADMIN
}
