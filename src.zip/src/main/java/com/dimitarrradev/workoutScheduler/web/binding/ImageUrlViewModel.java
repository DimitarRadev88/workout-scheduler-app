package com.dimitarrradev.workoutScheduler.web.binding;

public record ImageUrlViewModel(
        Long id,
        String url
) {
}
