package com.dimitarrradev.workoutScheduler.web.binding;

public record UserLoginBindingModel(
    String username,
    String password
) {}

